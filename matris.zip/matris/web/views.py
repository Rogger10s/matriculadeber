from django.shortcuts import render

# Create your views here.
from matriculacion.models import Alumno, Materia
from .serializable import AlumnoSerializable,MateriaSerializable
from rest_framework import viewsets


class alumViewSet(viewsets.ModelViewSet):
	#llamo al objeto serializable
	serializer_class= AlumnoSerializable
	#defino la consulta de datos que se enviara en el web service
	queryset = Alumno.objects.all().order_by('apellido')
class mateViewSet(viewsets.ModelViewSet):
	#llamo al objeto serializable
	serializer_class= MateriaSerializable
	#defino la consulta de datos que se enviara en el web service
	queryset = Materia.objects.filter(cupos__gt=0)




