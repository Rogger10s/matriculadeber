from rest_framework import serializers
from matriculacion.models import Alumno, Materia


class AlumnoSerializable(serializers.ModelSerializer):
	class Meta:
		model = Alumno
		fields = ('nombre','apellido','cedula')

class MateriaSerializable(serializers.ModelSerializer):
	class Meta:
		model = Materia
		fields = ('materia','cupos')