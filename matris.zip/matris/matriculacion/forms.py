from django import forms
from .models import Alumno
from .models import Materia

class falum(forms.Form):
	nombre=forms.CharField(max_length=25)
	apellido=forms.CharField(max_length=20)
	cedula=forms.CharField(max_length=10)

class fmate(forms.Form):
	materia=forms.CharField(max_length=30)
	cupos=forms.IntegerField()
