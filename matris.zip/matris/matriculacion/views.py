from django.shortcuts import render, redirect

# Create your views here.
from .forms import  fmate
from .forms import falum
from .models import Alumno
from .models import Materia

def listar(request):
	alumnos=Alumno.objects.all()
	materias=Materia.objects.all()
	context={
		'a':alumnos,
		'm':materias,
	}
	return render(request,"listar.html",context)
def crearal(request):
	a=falum(request.POST or None)

	if request.method == 'POST':
		if a.is_valid():
			aa=a.cleaned_data
			al=Alumno()
			al.nombre= aa.get("nombre")
			al.apellido=aa.get("apellido")
			al.cedula=aa.get("cedula")
			
			if(al.save() != True):
				return redirect(listar)
	context={
		'ff':a,
	}
	return render(request,"crearal.html",context)
def crearmate(request):
	ma=fmate(request.POST or None)
	if request.method == 'POST':
		if ma.is_valid():
			mates=ma.cleaned_data
			m=Materia()
			m.materia=mates.get("materia")
			m.cupos=mates.get("cupos")
			
			if(m.save() != True):
				return redirect(listar)

	context={
		'mm':ma
	}
	return render(request,"crearm.html",context)