from django.conf.urls import url, patterns
from django.contrib import admin

from . import views
urlpatterns=[ 
	
	url(r'^$', 'matriculacion.views.listar'),
	url(r'^crearal/$', 'matriculacion.views.crearal'),
	url(r'^crearmate/$', 'matriculacion.views.crearmate'),
]