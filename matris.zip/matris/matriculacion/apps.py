from django.apps import AppConfig


class MatriculacionConfig(AppConfig):
    name = 'matriculacion'
